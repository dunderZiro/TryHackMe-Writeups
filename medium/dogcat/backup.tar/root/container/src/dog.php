<img src="dogs/<?php echo rand(1, 10); ?>.jpg" />
