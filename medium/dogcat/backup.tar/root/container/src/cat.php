<img src="cats/<?php echo rand(1, 10); ?>.jpg" />
