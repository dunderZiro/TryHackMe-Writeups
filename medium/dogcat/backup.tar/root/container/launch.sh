#!/bin/bash
docker run -d -p 80:80 -v /root/container/backup:/opt/backups --rm box
