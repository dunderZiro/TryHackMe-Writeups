#!/bin/bash
tar cf /root/container/backup/backup.tar /root/container
